-- Minimal Postgres schema for dispute automation MVP

create table if not exists merchants (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  name text,
  email text,
  stripe_account_id text unique,
  stripe_access_token text,
  metadata jsonb default '{}'::jsonb
);

create table if not exists disputes (
  id text primary key,
  created_at timestamptz default now(),
  account_id text not null,
  charge_id text,
  amount integer,
  currency text,
  reason text,
  status text,
  evidence_due_at timestamptz,
  raw jsonb
);

create table if not exists responses (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  dispute_id text references disputes(id) on delete cascade,
  draft text,
  submitted boolean default false,
  submitted_at timestamptz
);
